package Blackjack;

public class BlackjackMain {

    public static void main(String[] args) {
        Game theGame = new Game();
        theGame.playRound();
    }
}
